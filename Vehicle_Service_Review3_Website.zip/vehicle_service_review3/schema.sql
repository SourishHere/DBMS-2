PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS CUSTOMER (
    Customer_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    Customer_Name TEXT NOT NULL,
    Phone TEXT NOT NULL,
    Email TEXT UNIQUE,
    Address TEXT
);

CREATE TABLE IF NOT EXISTS VEHICLE_MODEL (
    Model_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    Brand TEXT NOT NULL,
    Model_Name TEXT NOT NULL,
    Fuel_Type TEXT NOT NULL DEFAULT 'Petrol' CHECK (Fuel_Type IN ('Petrol','Diesel','Electric','Hybrid','CNG')),
    Vehicle_Type TEXT NOT NULL DEFAULT 'Car' CHECK (Vehicle_Type IN ('Car','Bike','SUV','Truck','Van')),
    UNIQUE (Brand, Model_Name)
);

CREATE TABLE IF NOT EXISTS VEHICLE (
    Vehicle_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    Registration_No TEXT NOT NULL UNIQUE,
    Customer_ID INTEGER NOT NULL,
    Model_ID INTEGER NOT NULL,
    Manufacture_Year INTEGER CHECK (Manufacture_Year >= 1900),
    Mileage REAL NOT NULL DEFAULT 0 CHECK (Mileage >= 0),
    FOREIGN KEY (Customer_ID) REFERENCES CUSTOMER(Customer_ID),
    FOREIGN KEY (Model_ID) REFERENCES VEHICLE_MODEL(Model_ID)
);

CREATE TABLE IF NOT EXISTS MECHANIC (
    Mechanic_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    Mechanic_Name TEXT NOT NULL,
    Phone TEXT NOT NULL UNIQUE,
    Specialization TEXT
);

CREATE TABLE IF NOT EXISTS SERVICE_TYPE (
    Service_Type_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    Service_Name TEXT NOT NULL UNIQUE,
    Description TEXT,
    Price REAL NOT NULL DEFAULT 0 CHECK (Price >= 0)
);

CREATE TABLE IF NOT EXISTS APPOINTMENT (
    Appointment_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    Vehicle_ID INTEGER NOT NULL,
    Mechanic_ID INTEGER NOT NULL,
    Service_Type_ID INTEGER NOT NULL,
    Appointment_Date TEXT NOT NULL,
    Status TEXT NOT NULL DEFAULT 'Booked' CHECK (Status IN ('Booked','In Progress','Completed','Cancelled')),
    Notes TEXT,
    FOREIGN KEY (Vehicle_ID) REFERENCES VEHICLE(Vehicle_ID),
    FOREIGN KEY (Mechanic_ID) REFERENCES MECHANIC(Mechanic_ID),
    FOREIGN KEY (Service_Type_ID) REFERENCES SERVICE_TYPE(Service_Type_ID)
);

CREATE TABLE IF NOT EXISTS SERVICE_RECORD (
    Service_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    Appointment_ID INTEGER NOT NULL UNIQUE,
    Service_Date TEXT NOT NULL,
    Cost REAL NOT NULL DEFAULT 0 CHECK (Cost >= 0),
    Description TEXT,
    FOREIGN KEY (Appointment_ID) REFERENCES APPOINTMENT(Appointment_ID)
);

CREATE TABLE IF NOT EXISTS SUPPLIER (
    Supplier_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    Supplier_Name TEXT NOT NULL,
    Phone TEXT,
    Email TEXT UNIQUE,
    Address TEXT
);

CREATE TABLE IF NOT EXISTS PART (
    Part_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    Part_Name TEXT NOT NULL,
    Supplier_ID INTEGER NOT NULL,
    Unit_Price REAL NOT NULL DEFAULT 0 CHECK (Unit_Price >= 0),
    FOREIGN KEY (Supplier_ID) REFERENCES SUPPLIER(Supplier_ID)
);

CREATE TABLE IF NOT EXISTS SERVICE_PART (
    Service_ID INTEGER NOT NULL,
    Part_ID INTEGER NOT NULL,
    Quantity INTEGER NOT NULL DEFAULT 1 CHECK (Quantity > 0),
    PRIMARY KEY (Service_ID, Part_ID),
    FOREIGN KEY (Service_ID) REFERENCES SERVICE_RECORD(Service_ID),
    FOREIGN KEY (Part_ID) REFERENCES PART(Part_ID)
);

CREATE TABLE IF NOT EXISTS INVENTORY (
    Inventory_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    Part_ID INTEGER NOT NULL UNIQUE,
    Quantity_In_Stock INTEGER NOT NULL DEFAULT 0 CHECK (Quantity_In_Stock >= 0),
    Last_Updated TEXT DEFAULT CURRENT_DATE,
    FOREIGN KEY (Part_ID) REFERENCES PART(Part_ID)
);

CREATE TABLE IF NOT EXISTS INVOICE (
    Invoice_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    Service_ID INTEGER NOT NULL UNIQUE,
    Invoice_Date TEXT NOT NULL DEFAULT CURRENT_DATE,
    Total_Amount REAL NOT NULL DEFAULT 0 CHECK (Total_Amount >= 0),
    Payment_Status TEXT NOT NULL DEFAULT 'Pending' CHECK (Payment_Status IN ('Pending','Paid','Partially Paid')),
    FOREIGN KEY (Service_ID) REFERENCES SERVICE_RECORD(Service_ID)
);

CREATE TABLE IF NOT EXISTS PAYMENT (
    Payment_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    Invoice_ID INTEGER NOT NULL,
    Payment_Date TEXT NOT NULL DEFAULT CURRENT_DATE,
    Amount REAL NOT NULL CHECK (Amount >= 0),
    Payment_Mode TEXT NOT NULL CHECK (Payment_Mode IN ('Cash','Card','UPI','Bank Transfer')),
    FOREIGN KEY (Invoice_ID) REFERENCES INVOICE(Invoice_ID)
);

CREATE TABLE IF NOT EXISTS WARRANTY (
    Warranty_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    Service_ID INTEGER,
    Part_ID INTEGER,
    Start_Date TEXT NOT NULL,
    End_Date TEXT NOT NULL,
    Details TEXT,
    CHECK (End_Date >= Start_Date),
    FOREIGN KEY (Service_ID) REFERENCES SERVICE_RECORD(Service_ID),
    FOREIGN KEY (Part_ID) REFERENCES PART(Part_ID)
);

CREATE TABLE IF NOT EXISTS FEEDBACK (
    Feedback_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    Service_ID INTEGER NOT NULL,
    Customer_ID INTEGER NOT NULL,
    Rating INTEGER NOT NULL CHECK (Rating BETWEEN 1 AND 5),
    Comments TEXT,
    Feedback_Date TEXT DEFAULT CURRENT_DATE,
    FOREIGN KEY (Service_ID) REFERENCES SERVICE_RECORD(Service_ID),
    FOREIGN KEY (Customer_ID) REFERENCES CUSTOMER(Customer_ID)
);

CREATE VIEW IF NOT EXISTS CustomerVehicleAppointment AS
SELECT c.Customer_ID, c.Customer_Name, c.Phone, c.Email,
       v.Vehicle_ID, v.Registration_No, vm.Brand, vm.Model_Name,
       a.Appointment_ID, a.Appointment_Date, a.Status
FROM CUSTOMER c
JOIN VEHICLE v ON c.Customer_ID = v.Customer_ID
JOIN VEHICLE_MODEL vm ON v.Model_ID = vm.Model_ID
LEFT JOIN APPOINTMENT a ON v.Vehicle_ID = a.Vehicle_ID;

INSERT INTO CUSTOMER (Customer_Name, Phone, Email, Address)
SELECT 'Ravi Kumar', '9876543210', 'ravi@example.com', 'Vellore'
WHERE NOT EXISTS (SELECT 1 FROM CUSTOMER);
INSERT INTO CUSTOMER (Customer_Name, Phone, Email, Address)
SELECT 'Priya Sharma', '9876543211', 'priya@example.com', 'Katpadi'
WHERE (SELECT COUNT(*) FROM CUSTOMER) < 2;

INSERT INTO VEHICLE_MODEL (Brand, Model_Name, Fuel_Type, Vehicle_Type)
SELECT 'Maruti Suzuki', 'Swift', 'Petrol', 'Car'
WHERE NOT EXISTS (SELECT 1 FROM VEHICLE_MODEL);
INSERT INTO VEHICLE_MODEL (Brand, Model_Name, Fuel_Type, Vehicle_Type)
SELECT 'Hyundai', 'i20', 'Petrol', 'Car'
WHERE (SELECT COUNT(*) FROM VEHICLE_MODEL) < 2;

INSERT INTO VEHICLE (Registration_No, Customer_ID, Model_ID, Manufacture_Year, Mileage)
SELECT 'TN23AB1234', (SELECT Customer_ID FROM CUSTOMER ORDER BY Customer_ID LIMIT 1),
       (SELECT Model_ID FROM VEHICLE_MODEL ORDER BY Model_ID LIMIT 1), 2022, 18000
WHERE NOT EXISTS (SELECT 1 FROM VEHICLE);
INSERT INTO VEHICLE (Registration_No, Customer_ID, Model_ID, Manufacture_Year, Mileage)
SELECT 'TN23CD5678', (SELECT Customer_ID FROM CUSTOMER ORDER BY Customer_ID DESC LIMIT 1),
       (SELECT Model_ID FROM VEHICLE_MODEL ORDER BY Model_ID DESC LIMIT 1), 2021, 42000
WHERE (SELECT COUNT(*) FROM VEHICLE) < 2;

INSERT INTO MECHANIC (Mechanic_Name, Phone, Specialization)
SELECT 'Arun', '9000000001', 'General Service'
WHERE NOT EXISTS (SELECT 1 FROM MECHANIC);
INSERT INTO MECHANIC (Mechanic_Name, Phone, Specialization)
SELECT 'Karthik', '9000000002', 'Engine'
WHERE (SELECT COUNT(*) FROM MECHANIC) < 2;

INSERT INTO SERVICE_TYPE (Service_Name, Description, Price)
SELECT 'General Service', 'Oil and routine inspection', 2500
WHERE NOT EXISTS (SELECT 1 FROM SERVICE_TYPE);
INSERT INTO SERVICE_TYPE (Service_Name, Description, Price)
SELECT 'Engine Check', 'Engine diagnostics', 1500
WHERE (SELECT COUNT(*) FROM SERVICE_TYPE) < 2;

INSERT INTO APPOINTMENT (Vehicle_ID, Mechanic_ID, Service_Type_ID, Appointment_Date, Status, Notes)
SELECT (SELECT Vehicle_ID FROM VEHICLE ORDER BY Vehicle_ID LIMIT 1),
       (SELECT Mechanic_ID FROM MECHANIC ORDER BY Mechanic_ID LIMIT 1),
       (SELECT Service_Type_ID FROM SERVICE_TYPE ORDER BY Service_Type_ID LIMIT 1),
       date('now','-3 day'), 'Completed', 'Demo completed service'
WHERE NOT EXISTS (SELECT 1 FROM APPOINTMENT);
INSERT INTO APPOINTMENT (Vehicle_ID, Mechanic_ID, Service_Type_ID, Appointment_Date, Status, Notes)
SELECT (SELECT Vehicle_ID FROM VEHICLE ORDER BY Vehicle_ID DESC LIMIT 1),
       (SELECT Mechanic_ID FROM MECHANIC ORDER BY Mechanic_ID DESC LIMIT 1),
       (SELECT Service_Type_ID FROM SERVICE_TYPE ORDER BY Service_Type_ID DESC LIMIT 1),
       date('now','+2 day'), 'Booked', 'Demo upcoming appointment'
WHERE (SELECT COUNT(*) FROM APPOINTMENT) < 2;

INSERT INTO SERVICE_RECORD (Appointment_ID, Service_Date, Cost, Description)
SELECT Appointment_ID, Appointment_Date, 2500, 'Routine oil change and inspection'
FROM APPOINTMENT WHERE Status='Completed'
AND NOT EXISTS (SELECT 1 FROM SERVICE_RECORD);
INSERT INTO SUPPLIER (Supplier_Name, Phone, Email, Address)
SELECT 'Auto Parts Co', '9000000010', 'sales@autoparts.example', 'Vellore'
WHERE NOT EXISTS (SELECT 1 FROM SUPPLIER);
INSERT INTO PART (Part_Name, Supplier_ID, Unit_Price)
SELECT 'Oil Filter', Supplier_ID, 450 FROM SUPPLIER
WHERE NOT EXISTS (SELECT 1 FROM PART);
INSERT INTO INVENTORY (Part_ID, Quantity_In_Stock)
SELECT Part_ID, 20 FROM PART
WHERE NOT EXISTS (SELECT 1 FROM INVENTORY);
INSERT INTO INVOICE (Service_ID, Total_Amount, Payment_Status)
SELECT Service_ID, Cost, 'Pending' FROM SERVICE_RECORD
WHERE NOT EXISTS (SELECT 1 FROM INVOICE);
